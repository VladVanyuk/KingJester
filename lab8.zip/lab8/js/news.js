/*function showTasks(){
  var lsLen = localStorage.length;
  if(lsLen > 0){
      for(var i = 0; i < lsLen; i++){
          var key = localStorage.key(i);
          if(key.charAt(0) == "s") {
              if(localStorage.getItem(key)!=null) {
                  $('        <div class="col-lg-3 col-md-9 col-xs-10 col-sm-10 border toDel marg-right">\n' +
                      '            <img  style="width: 100%" src="'+ localStorage.getItem(key) +'">\n' +
                      '            <p class="news">'+ localStorage.getItem("title"+key.slice(3))+'</p>\n' +
                      '            <p>'+ localStorage.getItem("inf"+key.slice(3))+'</p>\n' +
                      '           <button type="button" class="btn btn-danger delete w-100">Delete</button>  \n' +
                      '        </div>').addClass('tdItem')
                      .attr('data-itemid', key)
                      .addClass('tdItem')
                      .appendTo($(".main"));
              }
          }
      }
  }
}


window.onload = function(){

  if (navigator.onLine){
     $("#result").css("display", "inline");
     showTasks();
  }else{
    $("#result").css("display", "none");

  }
  


$(document).on('click','.delete', function(e){
  var jet = $(e.target);
  localStorage.removeItem($(".toDel").attr('data-itemid'));
  var num = $(".toDel").attr('data-itemid').slice(3);
  localStorage.removeItem("title"+num);
  localStorage.removeItem("inf"+num);
  $(this).closest(".toDel").remove();
  jet.remove();
  window.location.reload();

});

}   */

var useLocalStorage = false;

var on = navigator.onLine;
    var useLocalStorage = true;
    if(useLocalStorage) {
      if(!on){
      function showTasks() {
        var lsLen = localStorage.length;
        if (lsLen > 0) {
            for (var i = 0; i < lsLen; i++) {
                var key = localStorage.key(i);
                if (key.charAt(0) == "s") {
                    if (localStorage.getItem(key) != null) {
                        $('        <div class="col-lg-3 col-md-9 col-xs-10 col-sm-10 bg-white border toDel marg-right">\n' +
                            '            <img  style="width: 100%" src="' + localStorage.getItem(key) + '">\n' +
                            '            <p class="news">' + localStorage.getItem("title" + key.slice(3)) + '</p>\n' +
                            '            <p>' + localStorage.getItem("inf" + key.slice(3)) + '</p>\n' +
                            '           <button type="button" class="btn btn-danger delete w-100">Delete</button>  \n' +
                            '        </div>').addClass('tdItem')
                            .attr('data-itemid', key)
                            .addClass('tdItem')
                            .appendTo($(".main"));
                    }
                }
            }
        }
    }
      $(document).on('click', '.delete', function (e) {
        var jet = $(e.target);
        localStorage.removeItem($(".toDel").attr('data-itemid'));
        var num = $(".toDel").attr('data-itemid').slice(3);
        localStorage.removeItem("title" + num);
        localStorage.removeItem("inf" + num);
        $(this).closest(".toDel").remove();
        jet.remove();
        window.location.reload();

    });
    

    }
        
            
         
       
  } else {

    if (on) {
      window.indexedDB = window.indexedDB || window.mozIndexedDB || window.webkitIndexedDB || window.msIndexedDB;

      window.IDBTransaction = window.IDBTransaction || window.webkitIDBTransaction || window.msIDBTransaction || {READ_WRITE: "readwrite"};
      window.IDBKeyRange = window.IDBKeyRange || window.webkitIDBKeyRange || window.msIDBKeyRange;

      if (!window.indexedDB) {
          console.log("Your browser doesn't support a stable version of IndexedDB. Such and such feature will not be available.");
      }
      let db;

      init();

      async function init() {
          db = await idb.openDb('adminDb', 1, db => {
              db.createObjectStore('admin', {keyPath: 'name'});
          });

          list();
      }

      async function list() {
          let tx = db.transaction('admin');
          let Store = tx.objectStore('admin');

          let addmin = await Store.getAll();


          $("#main").append(addmin.map(addmin => '        <div class="col-lg-3 col-md-9 col-xs-10 col-sm-10 bg-dark border toDel marg-right">\n' +
              '            <img  style="width: 100%" src="img/images.png">\n' +
              '            <p class="news">' + addmin.name + '</p>\n' +
              '            <p>' + addmin.comment + '</p>\n' +
              '           <button type="button" class="btn btn-danger delete w-100">Delete</button>  \n' +
              '        </div>').join(''));


      }

      async function clearAppeals() {
          let tx = db.transaction('admin', 'readwrite');
          await tx.objectStore('admin').clear();
          await list();
      }

      async function addAppeal() {
          let name = document.getElementById('title').value;
          let comment = document.getElementById('comment').value;
          let now = new Date();

          let tx = db.transaction('admin', 'readwrite');
          document.getElementById('title').value = '';
          document.getElementById('comment').value = '';
          try {
              await tx.objectStore('admin').add({name, comment, now});
              await list();
          } catch (err) {
              if (err.name == 'ConstraintError') {
                  alert("This appeal is live");
                  await addAppeal();
              } else {
                  throw err;
              }
          }
      }
  
}

  }
    
        