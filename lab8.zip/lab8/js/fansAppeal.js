// var now = new Date;

//     function showTasks() {
//         var lsLen = localStorage.length;
//         if (lsLen > 0) {
//             for (var i = 0; i < lsLen; i++) {
//                 var key = localStorage.key(i);
//                 if (key.charAt(0) == "n") {
//                     if (localStorage.getItem(key) != null) {
//                         $('<div class="col-lg-8 col-md-12 col-sm-12 col-xs-12 new" style="margin-top: 60px;border-top: 2px solid white; margin-left: auto; margin-right: auto;">\n' +
//                             '    <div class="row" style="margin-top: 60px">\n' +
//                             '        <div class="col-lg-2 col-md-2 borderBox" style="line-height: 1">\n' +
//                             '    <p style="font-size: 13px">' + localStorage.getItem(key) + '</p>\n' +
//                             ' <p style="font-size: 13px">' + now + '</p>' +
//                             '        </div>\n' +
//                             '        <div class="col-lg-9 col-md-9 borderBox">\n' +
//                             '           <p>' + localStorage.getItem("comment" + key.slice(4)) + '</p> \n' +
//                             '        </div>\n' +
//                             '        <div class="col-lg-1 col-md-1 ">\n' +
//                             '           <button type="button" class="btn btn-danger delete h-50">Delete</button>  \n' +
//                             '        </div>\n' +
//                             '    </div>\n' +
//                             '</div>').addClass('tdItem')
//                             .attr('data-itemid', key)
//                             .addClass('tdItem')
//                             .appendTo($("#result"));
//                     }
//                 }
//             }
//         }
//     }
//         window.onload = function () {

//             if (navigator.onLine) {
//                 $("#result").css("display", "inline");
//                 showTasks();
//                 function check() {

//                     var name = $.trim($("#name").val());
//                     var comment = $.trim($("#comment").val());
//                     if (name !== "" & comment !== "") {
//                         alert("Data sent to server")
//                     } else {
//                         alert('Fields can\'t be empty');
//                     }
//                     document.getElementById('name').value = '';
//                     document.getElementById('comment').value = '';
//                 }
//                 document.getElementById('add').addEventListener('click', check);

//             } else {
//                 $("#result").css("display", "none");




//                 showTasks();
//                 var ID = 0;
//                 $(".new").each(function (index, el) {
//                     var nID = $(el).attr('data-itemid').slice(4);
//                     if (nID > ID)
//                         ID = nID;
//                 });

//                 function add() {
//                     var now = new Date();

//                     var name = $.trim($("#name").val());
//                     var comment = $.trim($("#comment").val());
//                     var html = '<div class="col-lg-8 col-md-12 col-sm-12 col-xs-12 new" style="margin-top: 60px;border-top: 2px solid white; margin-left: auto; margin-right: auto">\n' +
//                         '    <div class="row" style="margin-top: 60px">\n' +
//                         '        <div class="col-lg-2 col-md-2 borderBox" style="line-height: 1">\n' +
//                         '    <p style="font-size: 13px">' + name + '</p>\n' +
//                         ' <p style="font-size: 13px">' + now + '</p>' +
//                         '        </div>\n' +
//                         '        <div class="col-lg-9 col-md-9 borderBox">\n' +
//                         '           <p>' + comment + '</p> \n' +
//                         '        </div>\n' +
//                         '        <div class="col-lg-1 col-md-1 ">\n' +
//                         '           <button type="button" class="btn btn-danger delete h-50">Delete</button>  \n' +
//                         '        </div>\n' +
//                         '    </div>\n' +
//                         '</div>';

//                     if (name !== "" & comment !== "") {
//                         ID++;
//                         document.getElementById('result').innerHTML += html;
//                         localStorage.setItem("name" + ID, $("#name").val());
//                         localStorage.setItem("comment" + ID, $("#comment").val());
//                     } else {
//                         alert('Fields can\'t be empty');
//                     }
//                     document.getElementById('name').value = '';
//                     document.getElementById('comment').value = '';
//                     window.location.reload();
//                 }

//                 document.getElementById('add').addEventListener('click', add);


//                 $(document).on('click', '.delete', function (e) {
//                     var jet = $(e.target);
//                     localStorage.removeItem($(".new").attr('data-itemid'));
//                     var num = $(".new").attr('data-itemid').slice(4);
//                     localStorage.removeItem("comment" + num);
//                     $(this).closest(".new").remove();
//                     jet.remove();
//                     window.location.reload();

//                 });
//             }
//         }



// let db;

// init();

// async function init() {
//   db = await idb.openDb('appealDb', 1, db => {
//     db.createObjectStore('appeal', {keyPath: 'name'});
//   });

//   list();
// }

// async function list() {
//   let tx = db.transaction('appeal');
//   let Store = tx.objectStore('appeal');

//   let appeal = await Store.getAll();

  
//     listElem.innerHTML = appeal.map(appeall => '<div class="zag justify-content-center concert col-lg-12 col-md-12 col-xs-12 col-sm-12 ">'+
//                        '<div class=" col-lg-2 col-md-12 col-xs-12 col-sm-12">' + '<p class="block1">' + appeall.name +  '</br>' + appeall.now + '</p>' +
//                        '</div>' +  '<div class="block2 col-lg-6 col-md-12 col-xs-12 col-sm-12">'+
//                        '<p>' + appeall.fname  + '</p>' + 
//                        '</div>' + '</div>' +
//                        '<input type="submit" name="send" class="delete" value="Delete" id="delete" onclick="clearAppeals()">' +
//                        '<p style="text-align: center"><img src="content/decorative-line-black-png-picture-png-619.png"></p>').join('');
  


// }

// async function clearAppeals() {
//   let tx = db.transaction('appeal', 'readwrite');
//   await tx.objectStore('appeal').clear();
//   await list();
// }

// async function addAppeal() {
//   let name = document.getElementById('name').value;
//   let fname = document.getElementById('introduction').value;
//   let now = new Date();

//   let tx = db.transaction('appeal', 'readwrite');

//   try {
//     await tx.objectStore('appeal').add({name, fname, now});
//     await list();
//   } catch(err) {
//     if (err.name == 'ConstraintError') {
//       alert("This appeal is live");
//       await addAppeal();
//     } else {
//       throw err;
//     }
//   }
// }

// window.addEventListener('unhandledrejection', event => {
//   alert("Error: " + event.reason.message);
// });
//       }

//       else{
//         $('#say').on('click',function(){
//         alert('Дані відправлені на сервер')
//       });